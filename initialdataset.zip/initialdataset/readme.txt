for Gaussian shape profile

r0=120.d0
sigma=8.d0
phi0=1.d0/4.d1

0: standard GR
1: a2=1
2: a2=10
3: a2=Infinity (Let V=0)
4: case C of arXiv:1112.3928
5: case B of arXiv:1112.3928