# $Id: gocom.sh,v 1.1.1.1 2012/02/03 08:46:28 zjcao Exp $
#!/bin/bash
make ABE 2>&1 | tee make.log
